package Promedio;

import java.util.Scanner;

public class Promedio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn= new Scanner(System.in);
		
		int P[];
		int E[];
		int cant;
		System.out.println("Ingrese cantidad de Alumnos");
		cant=sn.nextInt();
		P= new int [cant];
		E= new int [cant];
		
		
		for (int i = 0; i < cant; i++) {
			System.out.println("Alumno "+(i+1)+" : ");
			sn.nextLine();
			System.out.println("Ingrese Nota de Ingles");
			int NE=sn.nextInt();
			System.out.println("Ingrese Nota de Matematica");
			int NM=sn.nextInt();
			System.out.println("Ingrese Nota de Español");
			int NES=sn.nextInt();
			System.out.println("Ingrese Nota de Fisica");
			int NF=sn.nextInt();
			
			int NT=NE+NM+NES+NF;
			int pro = NT/4;
			P[i]=pro;
			
			
		}
		
		
		for (int j = 0; j < cant; j++) {
			System.out.println("Alumno "+(j+1)+" : ");
			System.out.println("Promedio:"+ P[j]);
			
			
		}

	}

}
